int puzzle();
