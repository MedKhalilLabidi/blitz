#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_mixer.h"
#include"SDL/SDL_ttf.h"
#include"puzzle.h"

int main(int argc, char *argv[])
{  int carte[5][5];
int time0 = 0, timereal = 0;
   SDL_Surface *mur=NULL;
    SDL_Surface *ecran = NULL, *image1 = NULL, *image2 = NULL, *image3 = NULL, *image4 = NULL, *image5 = NULL, *image6 = NULL, *image7 = NULL, *image8 = NULL, *vide = NULL, *background = NULL,*back = NULL, *bravo = NULL, *image12 = NULL, *image13 = NULL, *image14 = NULL;
    SDL_Surface *wallup1 = NULL, *walldown1 = NULL, *wallright1 = NULL, *wallleft1 = NULL, *wallupright = NULL, *wallupleft = NULL, *walldownright = NULL, *walldownleft = NULL; 
    SDL_Surface *wallup2 = NULL, *walldown2 = NULL, *wallright2 = NULL, *wallleft2 = NULL;
    SDL_Surface *wallup3 = NULL, *walldown3 = NULL, *wallright3 = NULL, *wallleft3 = NULL;
    SDL_Rect positionImage1, positionImage2, positionImage3, positionImage4, positionImage5, positionImage6, positionImage7, positionImage8, positionVide, new, positionBackGround, positionBack;
    SDL_Rect positionUpRight, positionUpLeft, positionDownRight, positionDownLeft, positionImage12, positionImage13, positionImage14;
    SDL_Rect positionUp1, positionUp2, positionUp3, positionDown1, positionDown2, positionDown3, positionRight1, positionRight2, positionRight3, positionLeft1, positionLeft2, positionLeft3, positionBravo; 
    SDL_Event event;
    int continuer = 1;
    int m=5;

    SDL_Init(SDL_INIT_VIDEO);

    ecran = SDL_SetVideoMode(1080, 720, 32, SDL_HWSURFACE);
    SDL_WM_SetCaption("PUZZLE", NULL);

    
    image1 =IMG_Load("1.png");
    image2 =IMG_Load("2.png");
    image3 =IMG_Load("3.png");
    image4 =IMG_Load("4.png");
    image5 =IMG_Load("5.png");
    image6 =IMG_Load("6.png");
    image7 =IMG_Load("7.png");
    image8 =IMG_Load("8.png");
     vide  =IMG_Load("vide.png");

    wallup1 =IMG_Load("up.png");
    wallup2 =IMG_Load("up.png");
    wallup3 =IMG_Load("up.png");

    walldown1 =IMG_Load("down.png");
    walldown2 =IMG_Load("down.png");
    walldown3 =IMG_Load("down.png");

    wallright1 =IMG_Load("right.png");
    wallright2 =IMG_Load("right.png");
    wallright3 =IMG_Load("right.png");

    wallleft1 =IMG_Load("left.png");
    wallleft2 =IMG_Load("left.png");
    wallleft3 =IMG_Load("left.png");

    wallupright =IMG_Load("upright.png");
    wallupleft =IMG_Load("upleft.png");
    walldownright =IMG_Load("downright.png");
    walldownleft =IMG_Load("downleft.png");
    background =IMG_Load("background.png");
    back= IMG_Load("back.png");
    bravo= IMG_Load("bravo.png");
    image12 = IMG_Load("12.png");
    image13 = IMG_Load("13.png");
    image14 = IMG_Load("14.png");

    SDL_SetColorKey(image1, SDL_SRCCOLORKEY, SDL_MapRGB(image1->format, 0, 0, 255));


    positionBackGround.x = 0;
    positionBackGround.y = 0;

    positionBack.x = ecran->w / 4 - image1->w / 2 - 150;
    positionBack.y = ecran->h / 2 - image1->h / 2 - 150;

    positionImage12.x = ecran->w / 4 - image12->w / 2;
    positionImage12.y = ecran->h / 2 - image12->h / 2;

    positionImage13.x = ecran->w / 4 - image13->w / 2;
    positionImage13.y = ecran->h / 2 - image13->h / 2;

    positionImage14.x = ecran->w / 4 - image14->w / 2;
    positionImage14.y = ecran->h / 2 - image14->h / 2;  


    positionImage1.x = ecran->w / 4 - image1->w / 2;
    positionImage1.y = ecran->h / 2 - image1->h / 2;
    positionImage2.x = ecran->w / 4 - image2->w / 2 - 100;
    positionImage2.y = ecran->h / 2 - image2->h / 2 - 100;
    positionImage3.x = ecran->w / 4 - image3->w / 2;
    positionImage3.y = ecran->h / 2 - image3->h / 2 + 100;
    positionImage4.x = ecran->w / 4 - image4->w / 2 + 100;
    positionImage4.y = ecran->h / 2 - image4->h / 2;
    positionImage5.x = ecran->w / 4 - image5->w / 2;
    positionImage5.y = ecran->h / 2 - image5->h / 2 - 100;
    positionImage6.x = ecran->w / 4 - image6->w / 2 - 100;
    positionImage6.y = ecran->h / 2 - image6->h / 2;
    positionImage7.x = ecran->w / 4 - image7->w / 2 - 100;
    positionImage7.y = ecran->h / 2 - image7->h / 2 + 100;
    positionImage8.x = ecran->w / 4 - image8->w / 2 + 100;
    positionImage8.y = ecran->h / 2 - image8->h / 2 - 100;
    positionVide.x = ecran->w / 4 - vide->w / 2 + 100;
    positionVide.y = ecran->h / 2 - vide->h / 2 + 100;

    positionUp1.x = ecran->w / 4 - image1->w / 2 - 100;
    positionUp1.y = ecran->h / 2 - image1->h / 2 - 200;    
    positionUp2.x = ecran->w / 4 - image1->w / 2;
    positionUp2.y = ecran->h / 2 - image1->h / 2 - 200 ;
    positionUp3.x = ecran->w / 4 - image1->w / 2 + 100;
    positionUp3.y = ecran->h / 2 - image1->h / 2 - 200;

    positionDown1.x = ecran->w / 4 - image1->w / 2 - 100;
    positionDown1.y = ecran->h / 2 - image1->h / 2 + 200;    
    positionDown2.x = ecran->w / 4 - image1->w / 2;
    positionDown2.y = ecran->h / 2 - image1->h / 2 + 200;
    positionDown3.x = ecran->w / 4 - image1->w / 2 + 100;
    positionDown3.y = ecran->h / 2 - image1->h / 2 + 200;

    positionRight1.x = ecran->w / 4 - image1->w / 2 + 200;
    positionRight1.y = ecran->h / 2 - image1->h / 2 - 100;    
    positionRight2.x = ecran->w / 4 - image1->w / 2 + 200;
    positionRight2.y = ecran->h / 2 - image1->h / 2;
    positionRight3.x = ecran->w / 4 - image1->w / 2 + 200;
    positionRight3.y = ecran->h / 2 - image1->h / 2 + 100;

    positionLeft1.x = ecran->w / 4 - image1->w / 2 - 200;
    positionLeft1.y = ecran->h / 2 - image1->h / 2 - 100;    
    positionLeft2.x = ecran->w / 4 - image1->w / 2 - 200;
    positionLeft2.y = ecran->h / 2 - image1->h / 2;
    positionLeft3.x = ecran->w / 4 - image1->w / 2 - 200;
    positionLeft3.y = ecran->h / 2 - image1->h / 2 + 100;



    positionBravo.x = ecran->w / 4 - image1->w / 2 + 400;
    positionBravo.y = ecran->h / 2 - image1->h / 2;


/* -------------------------------------  



carte[0][0]=1;
carte[0][1]=1;
carte[0][2]=1;
carte[0][3]=1;
carte[0][4]=1;

carte[1][0]=1;
carte[1][1]=0;
carte[1][2]=0;
carte[1][3]=0;
carte[1][4]=1;

carte[2][0]=1;
carte[2][1]=0;
carte[2][2]=0;
carte[2][3]=0;
carte[2][4]=1;

carte[3][0]=1;
carte[3][1]=0;
carte[3][2]=0;
carte[3][3]=0;
carte[3][4]=1;

carte[4][0]=1;
carte[4][1]=1;
carte[4][2]=1;
carte[4][3]=1;
carte[4][4]=1;

*/






















    
    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                   break;

            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {

                    case SDLK_5:
                        {
           SDL_BlitSurface(image12, NULL, ecran, &positionImage12); 

}   


                    case SDLK_DOWN: // Flèche haut
                        positionVide.y-=100;

                        if(positionImage1.x==positionVide.x && positionImage1.y==positionVide.y)
                           {
                         	positionImage1.y+=100;    
			   } 
                        if(positionImage2.x==positionVide.x && positionImage2.y==positionVide.y)
                           {
                         	positionImage2.y+=100;    
			   }
                        if(positionImage3.x==positionVide.x && positionImage3.y==positionVide.y)
                           {
                         	positionImage3.y+=100;    
			   }
                        if(positionImage4.x==positionVide.x && positionImage4.y==positionVide.y)
                           {
                         	positionImage4.y+=100;    
			   }
                        if(positionImage5.x==positionVide.x && positionImage5.y==positionVide.y)
                           {
                         	positionImage5.y+=100;    
			   }
                        if(positionImage6.x==positionVide.x && positionImage6.y==positionVide.y)
                           {
                         	positionImage6.y+=100;    
			   }
                        if(positionImage7.x==positionVide.x && positionImage7.y==positionVide.y)
                           {
                         	positionImage7.y+=100;    
			   }
                        if(positionImage8.x==positionVide.x && positionImage8.y==positionVide.y)
                           {
                         	positionImage8.y+=100;    
			   }    
                        if((positionUp1.x==positionVide.x && positionUp1.y==positionVide.y) || (positionUp2.x==positionVide.x && positionUp2.y==positionVide.y) || (positionUp3.x==positionVide.x && positionUp3.y==positionVide.y))
                           {
                         	positionVide.y+=100;   
			   }                     
                        


                        break;
                    case SDLK_UP: // Flèche bas
                        positionVide.y+=100;

                        if(positionImage1.x==positionVide.x && positionImage1.y==positionVide.y)
                           {
                         	positionImage1.y-=100;    
			   } 
                        if(positionImage2.x==positionVide.x && positionImage2.y==positionVide.y)
                           {
                         	positionImage2.y-=100;    
			   }
                        if(positionImage3.x==positionVide.x && positionImage3.y==positionVide.y)
                           {
                         	positionImage3.y-=100;    
			   }
                        if(positionImage4.x==positionVide.x && positionImage4.y==positionVide.y)
                           {
                         	positionImage4.y-=100;    
			   }
                        if(positionImage5.x==positionVide.x && positionImage5.y==positionVide.y)
                           {
                         	positionImage5.y-=100;    
			   }
                        if(positionImage6.x==positionVide.x && positionImage6.y==positionVide.y)
                           {
                         	positionImage6.y-=100;    
			   }
                        if(positionImage7.x==positionVide.x && positionImage7.y==positionVide.y)
                           {
                         	positionImage7.y-=100;    
			   }
                        if(positionImage8.x==positionVide.x && positionImage8.y==positionVide.y)
                           {
                         	positionImage8.y-=100;    
			   }
                        if((positionDown1.x==positionVide.x && positionDown1.y==positionVide.y) || (positionDown2.x==positionVide.x && positionDown2.y==positionVide.y) || (positionDown3.x==positionVide.x && positionDown3.y==positionVide.y))
                           {
				positionVide.y-=100;
                           }


                        break;
                    case SDLK_LEFT: // Flèche droite
                        positionVide.x+=100;
                        if(positionImage1.x==positionVide.x && positionImage1.y==positionVide.y)
                           {
                         	positionImage1.x-=100;    
			   } 
                        if(positionImage2.x==positionVide.x && positionImage2.y==positionVide.y)
                           {
                         	positionImage2.x-=100;    
			   }
                        if(positionImage3.x==positionVide.x && positionImage3.y==positionVide.y)
                           {
                         	positionImage3.x-=100;    
			   }
                        if(positionImage4.x==positionVide.x && positionImage4.y==positionVide.y)
                           {
                         	positionImage4.x-=100;    
			   }
                        if(positionImage5.x==positionVide.x && positionImage5.y==positionVide.y)
                           {
                         	positionImage5.x-=100;    
			   }
                        if(positionImage6.x==positionVide.x && positionImage6.y==positionVide.y)
                           {
                         	positionImage6.x-=100;    
			   }
                        if(positionImage7.x==positionVide.x && positionImage7.y==positionVide.y)
                           {
                         	positionImage7.x-=100;    
			   }
                        if(positionImage8.x==positionVide.x && positionImage8.y==positionVide.y)
                           {
                         	positionImage8.x-=100;    
			   }
                        if((positionRight1.x==positionVide.x && positionRight1.y==positionVide.y) || (positionRight2.x==positionVide.x && positionRight2.y==positionVide.y) || (positionRight3.x==positionVide.x && positionRight3.y==positionVide.y))
                           {
				positionVide.x-=100;
                           }

                        break;
                    case SDLK_RIGHT: // Flèche gauche
                        positionVide.x-=100;

                        if(positionImage1.x==positionVide.x && positionImage1.y==positionVide.y)
                           {
                         	positionImage1.x+=100;    
			   } 
                        if(positionImage2.x==positionVide.x && positionImage2.y==positionVide.y)
                           {
                         	positionImage2.x+=100;    
			   }
                        if(positionImage3.x==positionVide.x && positionImage3.y==positionVide.y)
                           {
                         	positionImage3.x+=100;    
			   }
                        if(positionImage4.x==positionVide.x && positionImage4.y==positionVide.y)
                           {
                         	positionImage4.x+=100;    
			   }
                        if(positionImage5.x==positionVide.x && positionImage5.y==positionVide.y)
                           {
                         	positionImage5.x+=100;    
			   }
                        if(positionImage6.x==positionVide.x && positionImage6.y==positionVide.y)
                           {
                         	positionImage6.x+=100;    
			   }
                        if(positionImage7.x==positionVide.x && positionImage7.y==positionVide.y)
                           {
                         	positionImage7.x+=100;    
			   }
                        if(positionImage8.x==positionVide.x && positionImage8.y==positionVide.y)
                           {
                         	positionImage8.x+=100;    
			   }  
                        if((positionLeft1.x==positionVide.x && positionLeft1.y==positionVide.y) || (positionLeft2.x==positionVide.x && positionLeft2.y==positionVide.y) || (positionLeft3.x==positionVide.x && positionLeft3.y==positionVide.y))
                           {
				positionVide.x+=100;
                           }  



                        break;
                }

 

                break;
        }

    
        
        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));


        SDL_BlitSurface(wallup1, NULL, ecran, &positionUp1);
        SDL_BlitSurface(wallup2, NULL, ecran, &positionUp2);
        SDL_BlitSurface(wallup3, NULL, ecran, &positionUp3);

        SDL_BlitSurface(walldown1, NULL, ecran, &positionDown1);
        SDL_BlitSurface(walldown2, NULL, ecran, &positionDown2);
        SDL_BlitSurface(walldown3, NULL, ecran, &positionDown3);

        SDL_BlitSurface(wallright1, NULL, ecran, &positionRight1);
        SDL_BlitSurface(wallright2, NULL, ecran, &positionRight2);
        SDL_BlitSurface(wallright3, NULL, ecran, &positionRight3);

        SDL_BlitSurface(wallleft1, NULL, ecran, &positionLeft1);
        SDL_BlitSurface(wallleft2, NULL, ecran, &positionLeft2);
        SDL_BlitSurface(wallleft3, NULL, ecran, &positionLeft3);
        SDL_BlitSurface(background, NULL, ecran, &positionBackGround);
	SDL_BlitSurface(back, NULL, ecran, &positionBack);
        SDL_BlitSurface(vide, NULL, ecran, &positionVide);
        SDL_BlitSurface(image2, NULL, ecran, &positionImage2);
        SDL_BlitSurface(image3, NULL, ecran, &positionImage3);
        SDL_BlitSurface(image4, NULL, ecran, &positionImage4);
        SDL_BlitSurface(image5, NULL, ecran, &positionImage5);
        SDL_BlitSurface(image6, NULL, ecran, &positionImage6);
        SDL_BlitSurface(image7, NULL, ecran, &positionImage7);
        SDL_BlitSurface(image8, NULL, ecran, &positionImage8);
        SDL_BlitSurface(image1, NULL, ecran, &positionImage1);




        
        SDL_Flip(ecran);
   }

    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                   break;

            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {

                    case SDLK_5:
                        {
           SDL_BlitSurface(image12, NULL, ecran, &positionImage12); break;
                        }   
                }break;
        }break;



      if((positionVide.x == ecran->w / 4 - vide->w / 2 + 100) && (positionVide.y == ecran->h / 2 - vide->h / 2+100) && (positionImage1.x = ecran->w / 4 - image1->w / 2 - 100 ) && (positionImage1.y = ecran->h / 2 - image1->h / 2 -100) && (positionImage2.x = ecran->w / 4 - image2->w / 2) && (positionImage2.y = ecran->h / 2 - image2->h / 2 +100) && (positionImage3.x = ecran->w / 4 - image3->w / 2 - 100 ) && (positionImage3.y = ecran->h / 2 - image3->h / 2 +100 ) && (positionImage4.x = ecran->w / 4 - image4->w / 2 -100 ) && (positionImage4.y = ecran->h / 2 - image4->h / 2 ) && (positionImage5.x = ecran->w / 4 - image5->w / 2 ) && (positionImage5.y = ecran->h / 2 - image5->h / 2 ) && (positionImage6.x = ecran->w / 4 - image6->w / 2 +100 ) && (positionImage6.y = ecran->h / 2 - image6->h / 2 ) && (positionImage7.x = ecran->w / 4 - image7->w / 2 +100) && (positionImage7.y = ecran->h / 2 - image7->h / 2 -100) && (positionImage8.x = ecran->w / 4 - image8->w / 2 ) && (positionImage8.y = ecran->h / 2 - image8->h / 2 -100)   ) 
{
        SDL_BlitSurface(bravo, NULL, ecran, &positionBravo);

} 


        SDL_Flip(ecran);

     }

     timereal = SDL_GetTicks();
if((timereal - time0) > 120000)
{SDL_Quit();}


    SDL_FreeSurface(background);
    SDL_FreeSurface(back);
    SDL_FreeSurface(image1);
    SDL_FreeSurface(image2);
    SDL_FreeSurface(image3);
    SDL_FreeSurface(image4);
    SDL_FreeSurface(image5);
    SDL_FreeSurface(image6);
    SDL_FreeSurface(image7);
    SDL_FreeSurface(image8);
    SDL_FreeSurface(vide);

    SDL_FreeSurface(wallup1);
    SDL_FreeSurface(wallup2);
    SDL_FreeSurface(wallup3);

    SDL_FreeSurface(walldown1);
    SDL_FreeSurface(walldown2);
    SDL_FreeSurface(walldown3);

    SDL_FreeSurface(wallright1);
    SDL_FreeSurface(wallright2);
    SDL_FreeSurface(wallright3);

    SDL_FreeSurface(wallleft1);
    SDL_FreeSurface(wallleft2);
    SDL_FreeSurface(wallleft3);
    SDL_FreeSurface(bravo);

    SDL_FreeSurface(image12);
    SDL_FreeSurface(image13);
    SDL_FreeSurface(image14);        

    SDL_Quit();

    return EXIT_SUCCESS;
}




