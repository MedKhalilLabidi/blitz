#include<stdio.h>
#include<stdlib.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_mixer.h"
int main(void){
SDL_Surface *screen;
SDL_Surface *image = NULL,*num1 = NULL,*num2 = NULL,*num3 = NULL,*num4 = NULL,*num5 = NULL,*num6 = NULL,*num7 = NULL,*num8 = NULL,*num9 = NULL,*bravo = NULL;
SDL_Rect positionecran,positionnum1,positionnum2,positionnum3,positionnum4,positionnum5,positionnum6,positionnum7,positionnum8,positionnum9,positionbravo;
SDL_Event event;
int done=0;
int m=1;
char pause;
int time0 = 0, timereal = 0;

screen =SDL_SetVideoMode(1280,720,32,SDL_HWSURFACE | SDL_DOUBLEBUF);

image=IMG_Load("background.png");
num1=IMG_Load("1.png");
num2=IMG_Load("2.png");
num3=IMG_Load("3.png");
num4=IMG_Load("4.png");
num5=IMG_Load("5.png");
num6=IMG_Load("6.png");
num7=IMG_Load("7.png");
num8=IMG_Load("8.png");
bravo=IMG_Load("bravo.png");
   positionnum1.x=700;
   positionnum1.y=100;
   positionnum2.x=850;
   positionnum2.y=100;
   positionnum3.x=1000;
   positionnum3.y=100;
   positionnum4.x=700;
   positionnum4.y=250;
   positionnum5.x=850;
   positionnum5.y=250;
   positionnum6.x=1000;
   positionnum6.y=250;
   positionnum7.x=700;
   positionnum7.y=400;
   positionnum8.x=850;
   positionnum8.y=400;
   
   positionbravo.x=1250;
   positionbravo.y=550;








   positionecran.x=0;
   positionecran.y=0;


   positionecran.w=image->w;


   SDL_EnableKeyRepeat(10,10);
while(done!=1)
{   SDL_FillRect(screen,NULL,SDL_MapRGB(screen->format,255,225,255));
   SDL_BlitSurface(image,NULL,screen,&positionecran);
while(SDL_PollEvent(&event))
{switch(event.type)
{case SDL_QUIT:
done=1;
break;
case SDL_KEYDOWN:
{if(event.key.keysym.sym==SDLK_ESCAPE)
done=1;

if(event.key.keysym.sym==SDLK_a)
SDL_BlitSurface(num1,NULL,screen,&positionnum1);

if(event.key.keysym.sym==SDLK_b)

SDL_BlitSurface(num2,NULL,screen,&positionnum2);

if(event.key.keysym.sym==SDLK_c)
SDL_BlitSurface(num3,NULL,screen,&positionnum3);

if(event.key.keysym.sym==SDLK_d)
{SDL_BlitSurface(num4,NULL,screen,&positionnum4);

SDL_BlitSurface(bravo,NULL,screen,&positionbravo);
timereal = 0;
timereal = SDL_GetTicks();
if((timereal - time0) > 2000)
{SDL_Quit();}

}



break;
}

}
}
timereal = SDL_GetTicks();
if((timereal - time0) > 20000)
{SDL_Quit();}

 

   SDL_Flip(screen);
}




SDL_FreeSurface(num1);
SDL_FreeSurface(num2);
SDL_FreeSurface(num3);
SDL_FreeSurface(num4);
SDL_FreeSurface(num5);
SDL_FreeSurface(num6);
SDL_FreeSurface(num7);
SDL_FreeSurface(num8);
SDL_FreeSurface(bravo);

SDL_Quit();   
return 0;
}


